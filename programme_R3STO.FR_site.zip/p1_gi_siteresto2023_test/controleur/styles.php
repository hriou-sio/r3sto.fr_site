<?php
session_start();

// Définir le type de contenu CSS
header('Content-Type: text/css');

// Définir les couleurs par défaut
$bgColor = '#fff';
$textColor = '#000';

// Si le mode nuit est activé, changer les couleurs
if (isset($_SESSION['modeNuit']) && $_SESSION['modeNuit'] === true) {
    $bgColor = '#191919';
    $textColor = '#fff';
    $signColor = "#FF00FF";
}

// Générer le CSS
echo "
body {
    background-color: $bgColor;
    color: $textColor;
}

#corps {
    background-color: $bgColor;
}

div.card {
    background-color: $bgColor;
}

.maj {
    background-color: $signColor;
";
?>