<?php
use modele\metier\Critique;
use modele\metier\Utilisateur;
use modele\dao\Bdd;
require_once '../../includes/autoload.inc.php';  // Assurez-vous que ce chemin est correct

$user = new Utilisateur(6, 'test@bts.sio', 'seSzpoUAQgIl', 'testeur SIO');
$uneCritique = new Critique(5, "Parfait", $user);
?>
<h2>Test unitaire de la classe Critique</h2>
<?php
var_dump($uneCritique);

