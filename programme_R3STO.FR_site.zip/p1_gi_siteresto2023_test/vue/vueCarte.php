<?php
// ...
use modele\dao\CritiqueDAO;
use modele\dao\RestoDAO;
// Remplacez cette partie par l'inclusion de votre configuration et vos classes
require_once __DIR__ . "/../modele/metier/Resto.class.php";
require_once __DIR__ . "/../modele/dao/RestoDAO.class.php";
require_once __DIR__ . "/../modele/dao/CritiqueDAO.class.php";


// Obtenez la liste des restaurants en utilisant la méthode getAll
$listeRestos = RestoDAO::getAll();
?>

<div id="accroche">Découvrez les meilleurs restaurants avec resto.fr</div>
<h1>Carte des restaurants</h1>

<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Inclure la bibliothèque Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

    <style>
        #map {
            height: 500px;
            width: 100%;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
    <!-- Ajouter la carte interactive -->
    <div id="map"></div>

    <script>
        // Initialiser la carte Leaflet
        var map = L.map('map').setView([0, 0], 2); // Centre de la carte (lat, long), zoom

        // Ajouter une couche de carte OpenStreetMap
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Ajouter des marqueurs pour chaque restaurant
        
        <?php foreach ($listeRestos as $unResto) : ?>
            <?php
            //récupère la photo du restaurant
            $lesPhotos = $unResto->getLesPhotos();
            if (count($lesPhotos) > 0) {
                $laPhotoPrincipale = $lesPhotos[0];
            }
            //récupère les coordonnées géographiques du restaurant
            $latitude = $unResto->getLatitudeDegR();
            $longitude = $unResto->getLongitudeDegR();
            
            //récupère l'id du restaurant pour afficher sa note
            $idR = $unResto->getIdr();
            
            //récupère la moyenne du restaurant pour afficher la note
            $noteMoyenne = CritiqueDAO::getNoteMoyenneByIdR($idR);
            if($noteMoyenne == -1){
                $noteMoyenne = "Aucun avis";
            }
            
            //récupère les horaires du restaurant
            $horaires = $unResto->getHorairesR();

            if ($latitude !== null && $longitude !== null && is_numeric($latitude) && is_numeric($longitude)) :
            ?>
                var marker = L.marker([<?= $latitude ?>, <?= $longitude ?>])
                    .addTo(map)
                    // Popup avec les infos des restaurants
                    .bindPopup("<img src='photos/<?= $laPhotoPrincipale->getCheminP() ?>' alt='photo du restaurant' style='display: block; margin: 0 auto; width: 80%; max-width: 200px; border: 3px solid #ddd; border-radius: 5px; padding: 5px;' /> <br>\n\
                                <b>Nom du restaurant : </b><?= $unResto->getNomR()?> <br> \n\
                                <b>Adresse : </b><?=$unResto->getNumAdr()?> <?= $unResto->getVoieAdr() ?>, <?= $unResto->getCpR() ?>, <?= $unResto->getVilleR() ?> <br> \n\
                                <b>Note : </b><?=$noteMoyenne?> <br>\n\
                                <a href='http://10.15.253.250/hriou/p1_gi_siteresto2023_test/?action=detail&idR=<?= $unResto->getIdR() ?>'>Voir les détails</a>");
            <?php else : ?>
                console.error("Erreur de coordonnées pour le restaurant <?= $unResto->getNomR() ?>");
            <?php endif; ?>
        <?php endforeach; ?>
    </script>
</body>
</html>
