<?php
session_start();

// Vérifier si le bouton a été soumis
if (isset($_POST['toggleMode'])) {
    // Basculer entre le mode nuit et le mode jour
    $_SESSION['modeNuit'] = !isset($_SESSION['modeNuit']) || $_SESSION['modeNuit'] === false;
}

// Debug
var_dump($_SESSION['modeNuit']);

// Rediriger vers la page précédente
header('Location: ' . $_SERVER['HTTP_REFERER']);
exit();
?>