CREATE USER 'resto_util'@'localhost' IDENTIFIED BY 'secret';
GRANT ALL PRIVILEGES ON resto2.* TO 'resto_util'@'localhost';
